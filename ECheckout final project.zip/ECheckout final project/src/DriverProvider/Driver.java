package DriverProvider;

public interface Driver {
	String DRIVER="oracle.jdbc.driver.OracleDriver";  
	String CONNECTION_URL="jdbc:oracle:thin:@localhost:1521:xe";  
	String USERNAME="echeck";  
	String PASSWORD="abcd";  
}
